import { InlineMath, BlockMath } from 'react-katex';
import 'katex/dist/katex.min.css';

interface MathProps {
  formula: string;
  block?: boolean;
  className?: string;
}

const MathRenderer = ({ formula, block = false, className = '' }: MathProps) => {
  return block ? (
    <div className={`my-4 overflow-x-auto ${className}`}>
      <BlockMath math={formula} />
    </div>
  ) : (
    <span className={className}>
      <InlineMath math={formula} />
    </span>
  );
};

export default MathRenderer;
