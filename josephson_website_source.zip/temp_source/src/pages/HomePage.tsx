import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import MathRenderer from '../components/MathRenderer';

const HomePage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-800 to-indigo-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-6">约瑟夫森传输线研究</h1>
            <p className="text-xl md:text-2xl mb-8">Shunted与Unshunted结的偏置电流与脉冲高度比较</p>
            <div className="max-w-3xl mx-auto">
              <p className="text-lg mb-8">
                本研究从理论建模与公式推导角度，系统分析了为什么unshunted结组成的约瑟夫森传输线的偏置电流要比shunted结组成的约瑟夫森传输线偏置电流低，以及为什么unshunted的脉冲高度更高。
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Research Overview */}
        <section className="mb-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-800">研究概述</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <p className="mb-4">
              约瑟夫森传输线（Josephson Transmission Line, JTL）是超导电子学中的关键组件，广泛应用于单通量量子（SFQ）逻辑电路、超导量子干涉仪（SQUID）和超导量子比特等领域。JTL由一系列约瑟夫森结串联组成，用于传输和处理超导脉冲信号。
            </p>
            <p className="mb-4">
              约瑟夫森结可分为两种基本类型：shunted（分流）结和unshunted（无分流）结。shunted结在约瑟夫森结的基础上并联了一个外部电阻，而unshunted结则没有这个额外的电阻。这两种结构在性能上存在显著差异，特别是在偏置电流需求和脉冲高度方面。
            </p>
            <p>
              本研究通过建立物理模型、推导数学公式和分析物理机制，给出了这些现象的完整理论解释。
            </p>
          </div>
        </section>

        {/* Key Findings */}
        <section className="mb-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-800">主要发现</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
              <h3 className="text-xl font-semibold mb-4 text-blue-800">偏置电流比较</h3>
              <p className="mb-4">
                unshunted JTL所需的最小偏置电流低于shunted JTL
              </p>
              <div className="bg-blue-50 p-4 rounded-lg">
                <MathRenderer formula="i_{bias,c,un} < i_{bias,c,sh}" block />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-indigo-500">
              <h3 className="text-xl font-semibold mb-4 text-indigo-800">脉冲高度比较</h3>
              <p className="mb-4">
                在相同偏置电流下，unshunted JTL的脉冲高度高于shunted JTL
              </p>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <MathRenderer formula="V_{max,un} > V_{max,sh}" block />
              </div>
            </div>
          </div>
        </section>

        {/* Navigation Cards */}
        <section>
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-800">探索研究内容</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link to="/models" className="block">
              <div className="bg-white rounded-lg shadow-md p-6 h-full hover:shadow-lg transition-shadow duration-300">
                <h3 className="text-lg font-semibold mb-2 text-blue-800">基础模型</h3>
                <p className="text-gray-600">了解约瑟夫森结的基本原理和RCSJ模型</p>
              </div>
            </Link>
            <Link to="/transmission-line" className="block">
              <div className="bg-white rounded-lg shadow-md p-6 h-full hover:shadow-lg transition-shadow duration-300">
                <h3 className="text-lg font-semibold mb-2 text-blue-800">传输线理论</h3>
                <p className="text-gray-600">探索约瑟夫森传输线的动力学方程和孤子解</p>
              </div>
            </Link>
            <Link to="/bias-current" className="block">
              <div className="bg-white rounded-lg shadow-md p-6 h-full hover:shadow-lg transition-shadow duration-300">
                <h3 className="text-lg font-semibold mb-2 text-blue-800">偏置电流分析</h3>
                <p className="text-gray-600">理解临界偏置电流的推导和比较</p>
              </div>
            </Link>
            <Link to="/pulse-height" className="block">
              <div className="bg-white rounded-lg shadow-md p-6 h-full hover:shadow-lg transition-shadow duration-300">
                <h3 className="text-lg font-semibold mb-2 text-blue-800">脉冲高度分析</h3>
                <p className="text-gray-600">分析脉冲传播速度和高度计算</p>
              </div>
            </Link>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default HomePage;
