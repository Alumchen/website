import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const TransmissionLinePage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">约瑟夫森传输线理论</h1>

        {/* 传输线基本结构 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 传输线基本结构</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              约瑟夫森传输线（JTL）是由多个约瑟夫森结串联形成的超导传输线。在JTL中，约瑟夫森结之间通常由超导电感连接。
            </p>
            <div className="bg-gray-100 p-4 rounded-lg mb-4 text-center">
              <p className="italic text-gray-600">约瑟夫森传输线示意图</p>
            </div>
            <p className="mb-4">
              JTL的基本单元由约瑟夫森结和超导电感组成：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>约瑟夫森结：可以是Shunted或Unshunted结构</li>
              <li>超导电感 <MathRenderer formula="L" />：连接相邻约瑟夫森结</li>
            </ul>
          </div>
        </section>

        {/* 传输线动力学方程 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. 传输线动力学方程</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              对于由N个约瑟夫森结组成的JTL，可以建立以下离散方程：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{d^2\phi_j}{d\tau^2} + \alpha_j\frac{d\phi_j}{d\tau} + \sin(\phi_j) + \frac{1}{\lambda_J^2}(\phi_{j+1} - 2\phi_j + \phi_{j-1}) = i_{bias}" block />
            </div>
            <p className="mb-4">
              其中：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li><MathRenderer formula="\phi_j" /> 是第j个结的相位差</li>
              <li><MathRenderer formula="\alpha_j" /> 是第j个结的阻尼参数</li>
              <li><MathRenderer formula="\lambda_J = \sqrt{\frac{\hbar}{2eI_cL}}" /> 是约瑟夫森穿透深度</li>
              <li><MathRenderer formula="i_{bias} = \frac{I_{bias}}{I_c}" /> 是归一化偏置电流</li>
            </ul>

            <p className="mb-4">
              在连续近似下，可以得到波动方程：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{\partial^2\phi}{\partial \tau^2} + \alpha\frac{\partial\phi}{\partial\tau} + \sin(\phi) - \lambda_J^2\frac{\partial^2\phi}{\partial x^2} = i_{bias}" block />
            </div>
            <p className="mb-4">
              其中<MathRenderer formula="x" />是归一化的空间坐标。
            </p>
          </div>
        </section>

        {/* 孤子解分析 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. 孤子解分析</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              在特定条件下，上述方程存在孤子解（soliton solution），也称为约瑟夫森涡旋（Josephson vortex）或磁通量子（fluxon）。对于小阻尼情况，孤子解的近似形式为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\phi(x,\tau) = 4\arctan\left[\exp\left(\frac{x-v\tau}{\sqrt{1-v^2}}\right)\right]" block />
            </div>
            <p className="mb-4">
              其中<MathRenderer formula="v" />是归一化的孤子速度（相对于光速在约瑟夫森介质中的速度）。
            </p>
            <p className="mb-4">
              这个孤子解描述了一个相位差从0到2π的变化，对应于一个磁通量子在传输线中的传播。孤子的宽度与速度有关，速度越接近光速，孤子越窄（相对论收缩效应）。
            </p>
            <div className="bg-gray-100 p-4 rounded-lg mb-4 text-center">
              <p className="italic text-gray-600">约瑟夫森孤子传播示意图</p>
            </div>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default TransmissionLinePage;
