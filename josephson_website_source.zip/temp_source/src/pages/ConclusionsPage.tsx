import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const ConclusionsPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">结论与应用</h1>

        {/* 主要研究结论 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 主要研究结论</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              通过系统的理论建模与公式推导，我们得出以下结论：
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 text-blue-800">偏置电流比较</h3>
                <p className="mb-2">
                  unshunted JTL所需的最小偏置电流低于shunted JTL
                </p>
                <div className="bg-white p-3 rounded">
                  <MathRenderer formula="i_{bias,c,un} < i_{bias,c,sh}" block />
                </div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 text-indigo-800">脉冲高度比较</h3>
                <p className="mb-2">
                  在相同偏置电流下，unshunted JTL的脉冲高度高于shunted JTL
                </p>
                <div className="bg-white p-3 rounded">
                  <MathRenderer formula="V_{max,un} > V_{max,sh}" block />
                </div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-2 text-purple-800">传播速度比较</h3>
                <p className="mb-2">
                  在相同偏置电流下，unshunted JTL中的脉冲传播速度快于shunted JTL
                </p>
                <div className="bg-white p-3 rounded">
                  <MathRenderer formula="v_{un} > v_{sh}" block />
                </div>
              </div>
            </div>
            <p className="mb-4">
              这些结论直接回答了为什么unshunted结组成的约瑟夫森传输线的偏置电流要比shunted结组成的约瑟夫森传输线偏置电流低，以及为什么unshunted的脉冲高度更高的问题。
            </p>
            <p className="mb-4">
              核心原因在于shunt电阻引入的额外阻尼效应，这种阻尼一方面增加了维持脉冲传播所需的最小偏置电流，另一方面降低了脉冲的传播速度和高度。
            </p>
            <p className="mb-4">
              然而，需要注意的是，shunt电阻的引入也有其积极作用，如消除迟滞现象、提高稳定性和加快恢复时间等。在实际应用中，需要根据具体需求在这些因素之间进行权衡。
            </p>
          </div>
        </section>

        {/* 实际应用场景 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. 实际应用场景</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold mb-4 text-blue-700">Shunted JTL应用场景</h3>
                <ul className="list-disc pl-6 mb-4 space-y-2">
                  <li><strong>高频数字电路</strong>：需要快速恢复时间和高工作频率</li>
                  <li><strong>复杂逻辑电路</strong>：需要高稳定性和抗干扰能力</li>
                  <li><strong>标准SFQ电路</strong>：需要确定性行为和可预测性</li>
                  <li><strong>量子比特读出电路</strong>：需要高灵敏度和稳定性</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4 text-blue-700">Unshunted JTL应用场景</h3>
                <ul className="list-disc pl-6 mb-4 space-y-2">
                  <li><strong>低功耗应用</strong>：需要最小化偏置电流和功耗</li>
                  <li><strong>高灵敏度探测器</strong>：需要大信号响应和高脉冲高度</li>
                  <li><strong>量子计算前端</strong>：需要最小化热噪声和干扰</li>
                  <li><strong>特殊模拟电路</strong>：利用非线性动力学特性</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* 未来研究方向 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. 未来研究方向</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              基于本研究的结果，以下是一些值得进一步探索的方向：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li><strong>优化设计</strong>：探索shunted和unshunted结的混合设计，以平衡偏置电流需求和脉冲高度</li>
              <li><strong>温度效应</strong>：研究温度对shunted和unshunted JTL性能差异的影响</li>
              <li><strong>量子效应</strong>：在低温和小结尺寸下，深入研究量子效应对JTL动力学的影响</li>
              <li><strong>新材料探索</strong>：研究高温超导体和新型隧道结材料在JTL中的应用</li>
              <li><strong>非线性动力学</strong>：深入研究JTL中的混沌和非线性动力学现象</li>
            </ul>
          </div>
        </section>

        {/* 总结图表 */}
        <section>
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">4. 总结</h2>
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="mb-6">
              本研究从理论建模与公式推导角度，系统分析了shunted与unshunted约瑟夫森传输线的性能差异，特别是在偏置电流需求和脉冲高度方面。研究结果不仅解释了这些差异的物理机制，也为实际应用中的设计选择提供了理论依据。
            </p>
            <div className="bg-gray-100 p-4 rounded-lg text-center">
              <p className="italic text-gray-600">Shunted与Unshunted JTL性能对比总结图</p>
            </div>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default ConclusionsPage;
