import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const ModelsPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">约瑟夫森结基本模型</h1>

        {/* 约瑟夫森效应基本原理 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 约瑟夫森效应基本原理</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              约瑟夫森结是由两个超导体通过一个薄的绝缘层（隧道结）连接而成的器件。约瑟夫森效应描述了超导电子对（Cooper对）通过这个绝缘层的量子隧穿现象。约瑟夫森效应主要包含两个基本方程：
            </p>

            <h3 className="text-xl font-semibold mb-4 text-blue-700">1.1 直流约瑟夫森效应</h3>
            <p className="mb-4">
              描述超导电流与相位差的关系：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I_s = I_c \sin(\phi)" block />
            </div>
            <p className="mb-4">
              其中：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li><MathRenderer formula="I_s" /> 是通过结的超导电流</li>
              <li><MathRenderer formula="I_c" /> 是临界电流，即结能承载的最大超导电流</li>
              <li><MathRenderer formula="\phi" /> 是两个超导体之间的规范相位差</li>
            </ul>

            <h3 className="text-xl font-semibold mb-4 text-blue-700">1.2 交流约瑟夫森效应</h3>
            <p className="mb-4">
              描述相位差随时间变化与电压的关系：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{d\phi}{dt} = \frac{2e}{\hbar}V = \frac{2\pi}{\Phi_0}V" block />
            </div>
            <p className="mb-4">
              其中：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li><MathRenderer formula="V" /> 是结两端的电压</li>
              <li><MathRenderer formula="e" /> 是电子电荷</li>
              <li><MathRenderer formula="\hbar" /> 是约化普朗克常数</li>
              <li><MathRenderer formula="\Phi_0 = \frac{h}{2e}" /> 是磁通量子</li>
            </ul>
          </div>
        </section>

        {/* RCSJ模型 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. RCSJ模型</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              实际的约瑟夫森结可以用RCSJ（Resistively and Capacitively Shunted Junction）模型来描述，该模型将约瑟夫森结表示为理想约瑟夫森元件与电阻和电容的并联。
            </p>

            <h3 className="text-xl font-semibold mb-4 text-blue-700">2.1 Unshunted约瑟夫森结模型</h3>
            <div className="bg-gray-100 p-4 rounded-lg mb-4 text-center">
              <p className="italic text-gray-600">Unshunted约瑟夫森结等效电路图</p>
            </div>
            <p className="mb-4">
              Unshunted约瑟夫森结的等效电路包含：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>理想约瑟夫森元件（遵循约瑟夫森方程）</li>
              <li>结电容 <MathRenderer formula="C_J" />（由隧道结的几何结构决定）</li>
              <li>结电阻 <MathRenderer formula="R_J" />（表示准粒子隧穿导致的损耗）</li>
            </ul>

            <p className="mb-4">
              总电流可以表示为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{V}{R_J} + C_J\frac{dV}{dt}" block />
            </div>

            <p className="mb-4">
              结合交流约瑟夫森方程，可得：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{V}{R_J} + C_J\frac{d}{dt}\left(\frac{\hbar}{2e}\frac{d\phi}{dt}\right)" block />
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{\hbar}{2eR_J}\frac{d\phi}{dt} + \frac{\hbar C_J}{2e}\frac{d^2\phi}{dt^2}" block />
            </div>

            <p className="mb-4">
              引入归一化参数：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>归一化时间 <MathRenderer formula="\tau = \omega_p t" />，其中 <MathRenderer formula="\omega_p = \sqrt{\frac{2eI_c}{\hbar C_J}}" /> 是等离子体频率</li>
              <li>归一化电流 <MathRenderer formula="i = \frac{I}{I_c}" /></li>
              <li>阻尼参数 <MathRenderer formula="\alpha = \frac{1}{\omega_p R_J C_J} = \frac{\hbar}{2eR_JI_cC_J}" /></li>
            </ul>

            <p className="mb-4">
              可得归一化的动力学方程：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{d^2\phi}{d\tau^2} + \alpha\frac{d\phi}{d\tau} + \sin(\phi) = i" block />
            </div>

            <p className="mb-4">
              这是一个非线性二阶微分方程，类似于阻尼摆的运动方程。
            </p>

            <h3 className="text-xl font-semibold mb-4 text-blue-700">2.2 Shunted约瑟夫森结模型</h3>
            <div className="bg-gray-100 p-4 rounded-lg mb-4 text-center">
              <p className="italic text-gray-600">Shunted约瑟夫森结等效电路图</p>
            </div>
            <p className="mb-4">
              Shunted约瑟夫森结在Unshunted结的基础上，额外并联了一个外部分流电阻 <MathRenderer formula="R_{sh}" />。等效电路包含：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>理想约瑟夫森元件</li>
              <li>结电容 <MathRenderer formula="C_J" /></li>
              <li>结电阻 <MathRenderer formula="R_J" /></li>
              <li>外部分流电阻 <MathRenderer formula="R_{sh}" /></li>
            </ul>

            <p className="mb-4">
              总电流可以表示为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{V}{R_J} + \frac{V}{R_{sh}} + C_J\frac{dV}{dt}" block />
              <MathRenderer formula="I = I_c\sin(\phi) + V\left(\frac{1}{R_J} + \frac{1}{R_{sh}}\right) + C_J\frac{dV}{dt}" block />
            </div>

            <p className="mb-4">
              定义等效电阻 <MathRenderer formula="R_{eff} = \frac{R_J R_{sh}}{R_J + R_{sh}}" />，则：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{V}{R_{eff}} + C_J\frac{dV}{dt}" block />
            </div>

            <p className="mb-4">
              结合交流约瑟夫森方程，可得：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="I = I_c\sin(\phi) + \frac{\hbar}{2eR_{eff}}\frac{d\phi}{dt} + \frac{\hbar C_J}{2e}\frac{d^2\phi}{dt^2}" block />
            </div>

            <p className="mb-4">
              引入归一化参数：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>归一化时间 <MathRenderer formula="\tau = \omega_p t" /></li>
              <li>归一化电流 <MathRenderer formula="i = \frac{I}{I_c}" /></li>
              <li>阻尼参数 <MathRenderer formula="\alpha_{sh} = \frac{1}{\omega_p R_{eff} C_J} = \frac{\hbar}{2eR_{eff}I_cC_J}" /></li>
            </ul>

            <p className="mb-4">
              可得归一化的动力学方程：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{d^2\phi}{d\tau^2} + \alpha_{sh}\frac{d\phi}{d\tau} + \sin(\phi) = i" block />
            </div>
          </div>
        </section>

        {/* Shunted与Unshunted结的区别 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. Shunted与Unshunted结的关键区别</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-xl font-semibold mb-4 text-blue-700">3.1 阻尼参数比较</h3>
            <p className="mb-4">
              由于 <MathRenderer formula="R_{eff} < R_J" />（并联电阻总是小于任一单独电阻），因此：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\alpha_{sh} > \alpha" block />
            </div>
            <p className="mb-4">
              这意味着Shunted结具有更大的阻尼，其动力学行为更接近过阻尼状态。
            </p>

            <h3 className="text-xl font-semibold mb-4 text-blue-700">3.2 Stewart-McCumber参数</h3>
            <p className="mb-4">
              定义Stewart-McCumber参数 <MathRenderer formula="\beta_c = \frac{1}{\alpha^2}" />：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>对于Unshunted结：<MathRenderer formula="\beta_c = \frac{2eI_cR_J^2C_J}{\hbar}" /></li>
              <li>对于Shunted结：<MathRenderer formula="\beta_{c,sh} = \frac{2eI_cR_{eff}^2C_J}{\hbar}" /></li>
            </ul>
            <p className="mb-4">
              由于 <MathRenderer formula="R_{eff} < R_J" />，所以 <MathRenderer formula="\beta_{c,sh} < \beta_c" />
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>当 <MathRenderer formula="\beta_c \gg 1" /> 时，结处于欠阻尼状态，表现为迟滞行为</li>
              <li>当 <MathRenderer formula="\beta_c \ll 1" /> 时，结处于过阻尼状态，无迟滞行为</li>
            </ul>
            <p className="mb-4">
              Shunted结的主要目的是降低 <MathRenderer formula="\beta_c" /> 值，使结从欠阻尼状态转变为过阻尼状态，消除迟滞现象，提高结的稳定性和响应速度。
            </p>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default ModelsPage;
