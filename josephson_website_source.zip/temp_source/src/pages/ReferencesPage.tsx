import { motion } from 'framer-motion';

const ReferencesPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  const references = [
    {
      id: 1,
      author: 'Likharev, K. K.',
      year: 1986,
      title: 'Dynamics of Josephson Junctions and Circuits',
      publisher: 'Gordon and Breach Science Publishers',
      type: 'book'
    },
    {
      id: 2,
      author: 'Barone, A., & Paterno, G.',
      year: 1982,
      title: 'Physics and Applications of the Josephson Effect',
      publisher: 'Wiley',
      type: 'book'
    },
    {
      id: 3,
      author: 'Tinkham, M.',
      year: 2004,
      title: 'Introduction to Superconductivity',
      publisher: 'Dover Publications',
      type: 'book'
    },
    {
      id: 4,
      author: 'Ustinov, A. V.',
      year: 1998,
      title: 'Solitons in Josephson junctions',
      journal: 'Physica D: Nonlinear Phenomena',
      volume: '123(1-4)',
      pages: '315-329',
      type: 'article'
    },
    {
      id: 5,
      author: 'Kautz, R. L.',
      year: 1996,
      title: 'Noise, chaos, and the Josephson voltage standard',
      journal: 'Reports on Progress in Physics',
      volume: '59(8)',
      pages: '935',
      type: 'article'
    },
    {
      id: 6,
      author: 'Orlando, T. P., & Delin, K. A.',
      year: 1991,
      title: 'Foundations of Applied Superconductivity',
      publisher: 'Addison-Wesley',
      type: 'book'
    },
    {
      id: 7,
      author: 'Devoret, M. H., Martinis, J. M., & Clarke, J.',
      year: 1985,
      title: 'Measurements of Macroscopic Quantum Tunneling out of the Zero-Voltage State of a Current-Biased Josephson Junction',
      journal: 'Physical Review Letters',
      volume: '55(18)',
      pages: '1908',
      type: 'article'
    },
    {
      id: 8,
      author: 'Martinis, J. M., & Kautz, R. L.',
      year: 1989,
      title: 'Classical phase diffusion in small hysteretic Josephson junctions',
      journal: 'Physical Review Letters',
      volume: '63(14)',
      pages: '1507',
      type: 'article'
    }
  ];

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">参考文献</h1>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <p className="mb-6">
            以下是本研究中引用的主要参考文献，包括约瑟夫森结动力学、超导理论和非线性物理等领域的经典著作和重要论文。
          </p>

          <div className="space-y-6">
            {references.map((ref) => (
              <div key={ref.id} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
                <p className="text-lg font-medium text-gray-900">
                  [{ref.id}] {ref.author} ({ref.year})
                </p>
                <p className="text-gray-700 italic">{ref.title}</p>
                {ref.type === 'book' ? (
                  <p className="text-gray-600">{ref.publisher}</p>
                ) : (
                  <p className="text-gray-600">
                    {ref.journal}, {ref.volume}, {ref.pages}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-4 text-blue-800">相关资源</h2>
          <p className="mb-4">
            以下是一些与约瑟夫森结和超导电子学相关的在线资源和研究机构：
          </p>
          <ul className="list-disc pl-6 mb-4 space-y-2">
            <li><a href="#" className="text-blue-600 hover:underline">超导电子学国际会议 (ISEC)</a></li>
            <li><a href="#" className="text-blue-600 hover:underline">IEEE超导电子学委员会</a></li>
            <li><a href="#" className="text-blue-600 hover:underline">美国国家标准与技术研究院 (NIST) 超导研究组</a></li>
            <li><a href="#" className="text-blue-600 hover:underline">欧洲超导电子学协会</a></li>
            <li><a href="#" className="text-blue-600 hover:underline">日本超导电子学研究中心</a></li>
          </ul>
        </div>
      </div>
    </motion.div>
  );
};

export default ReferencesPage;
