import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const PulseHeightPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">脉冲高度理论分析</h1>

        {/* 脉冲传播速度推导 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 脉冲传播速度推导</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              孤子的传播速度与偏置电流和阻尼参数有关。在小阻尼情况下，归一化速度<MathRenderer formula="v" />满足：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\alpha v \approx \frac{\pi}{4}(i_{bias} - i_{bias,c})" block />
            </div>
            <p className="mb-4">
              将临界偏置电流表达式代入，可得：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\alpha v \approx \frac{\pi}{4}(i_{bias} - \frac{4\alpha}{\pi}) = \frac{\pi}{4}i_{bias} - \alpha" block />
            </div>
            <p className="mb-4">
              解得：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="v \approx \frac{\pi}{4\alpha}i_{bias} - 1" block />
            </div>
            <p className="mb-4">
              对于两种类型的JTL：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>unshunted JTL：<MathRenderer formula="v_{un} \approx \frac{\pi}{4\alpha}i_{bias} - 1" /></li>
              <li>shunted JTL：<MathRenderer formula="v_{sh} \approx \frac{\pi}{4\alpha_{sh}}i_{bias} - 1" /></li>
            </ul>
            <p className="mb-4">
              由于<MathRenderer formula="\alpha_{sh} > \alpha" />，所以在相同偏置电流下，<MathRenderer formula="v_{un} > v_{sh}" />，即<strong>unshunted JTL中的脉冲传播速度更快</strong>。
            </p>
          </div>
        </section>

        {/* 脉冲高度计算 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. 脉冲高度计算</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              根据交流约瑟夫森效应，结两端的电压与相位变化率成正比：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="V = \frac{\hbar}{2e}\frac{d\phi}{dt} = \frac{\Phi_0}{2\pi}\frac{d\phi}{dt}" block />
            </div>
            <p className="mb-4">
              对于传播中的孤子，相位变化率可以表示为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{d\phi}{dt} = -\frac{d\phi}{dx}\frac{dx}{dt} = -\frac{d\phi}{dx}v" block />
            </div>
            <p className="mb-4">
              其中<MathRenderer formula="v" />是孤子的传播速度。
            </p>
            <p className="mb-4">
              对于标准孤子解，相位的空间导数在孤子中心达到最大值：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\left.\frac{d\phi}{dx}\right|_{max} \approx \frac{2}{\sqrt{1-v^2}}" block />
            </div>
            <p className="mb-4">
              因此，脉冲电压的最大值（即脉冲高度）为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="V_{max} = \frac{\Phi_0}{2\pi}\left.\frac{d\phi}{dt}\right|_{max} = \frac{\Phi_0}{2\pi}\left.\frac{d\phi}{dx}v\right|_{max} \approx \frac{\Phi_0}{2\pi}\frac{2v}{\sqrt{1-v^2}}" block />
            </div>
          </div>
        </section>

        {/* Shunted与Unshunted结脉冲高度比较 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. Shunted与Unshunted结脉冲高度比较</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              对于给定的偏置电流<MathRenderer formula="i_{bias}" />，由于unshunted JTL中的脉冲传播速度更快（<MathRenderer formula="v_{un} > v_{sh}" />），根据上述公式，脉冲高度<MathRenderer formula="V_{max}" />随速度<MathRenderer formula="v" />的增加而增加。因此，<strong>unshunted JTL的脉冲高度更高</strong>。
            </p>
            <p className="mb-4">
              具体来说，如果两种JTL都工作在相同的归一化偏置电流<MathRenderer formula="i_{bias}" />下：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>unshunted JTL的脉冲高度：<MathRenderer formula="V_{max,un} \approx \frac{\Phi_0}{2\pi}\frac{2v_{un}}{\sqrt{1-v_{un}^2}}" /></li>
              <li>shunted JTL的脉冲高度：<MathRenderer formula="V_{max,sh} \approx \frac{\Phi_0}{2\pi}\frac{2v_{sh}}{\sqrt{1-v_{sh}^2}}" /></li>
            </ul>
            <p className="mb-4">
              由于<MathRenderer formula="v_{un} > v_{sh}" />，且函数<MathRenderer formula="f(v) = \frac{2v}{\sqrt{1-v^2}}" />在<MathRenderer formula="0 < v < 1" />范围内是单调递增的，所以<MathRenderer formula="V_{max,un} > V_{max,sh}" />。
            </p>
            <p className="mb-4">
              继续使用前面的参数，如果两种JTL都工作在相同的归一化偏置电流<MathRenderer formula="i_{bias} = 0.5" />下：
            </p>
            <p className="mb-4">
              对于unshunted JTL：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="v_{un} \approx \frac{\pi}{4\alpha}(0.5) - 1" block />
            </div>
            <p className="mb-4">
              对于shunted JTL：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="v_{sh} \approx \frac{\pi}{4\alpha_{sh}}(0.5) - 1 \approx \frac{\pi}{4(6\alpha)}(0.5) - 1 = \frac{1}{6}\left(\frac{\pi}{4\alpha}(0.5) - 1\right) + \frac{5}{6}(-1) = \frac{v_{un}}{6} - \frac{5}{6}" block />
            </div>
            <p className="mb-4">
              这表明shunted JTL中的脉冲速度显著低于unshunted JTL，从而导致脉冲高度也显著降低。
            </p>
            <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
              <p className="font-semibold text-yellow-800">关键结论</p>
              <p className="text-yellow-800">
                unshunted结的脉冲高度更高，这是由于shunt电阻降低了脉冲传播速度，而脉冲高度与传播速度成正相关。
              </p>
            </div>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default PulseHeightPage;
