import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const BiasCurrentPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">偏置电流理论分析</h1>

        {/* 临界偏置电流推导 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 临界偏置电流推导</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              对于JTL中的脉冲传播，存在一个临界偏置电流<MathRenderer formula="i_{bias,c}" />，只有当外部偏置电流超过这个临界值时，脉冲才能稳定传播。
            </p>
            <p className="mb-4">
              对于小阻尼情况，临界偏置电流与阻尼参数近似成正比：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="i_{bias,c} \approx \frac{4\alpha}{\pi}" block />
            </div>
            <p className="mb-4">
              这个关系可以通过能量平衡分析得出：脉冲在传播过程中由于阻尼而损失的能量必须由偏置电流提供的能量来补偿，才能维持稳定传播。
            </p>
          </div>
        </section>

        {/* 阻尼参数与偏置电流关系 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. 阻尼参数与偏置电流关系</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              根据前面的推导，阻尼参数与临界偏置电流成正比。对于两种类型的JTL：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>unshunted JTL：<MathRenderer formula="i_{bias,c,un} \approx \frac{4\alpha}{\pi} = \frac{4}{\pi}\frac{\hbar}{2eR_JI_cC_J}" /></li>
              <li>shunted JTL：<MathRenderer formula="i_{bias,c,sh} \approx \frac{4\alpha_{sh}}{\pi} = \frac{4}{\pi}\frac{\hbar}{2eR_{eff}I_cC_J}" /></li>
            </ul>
          </div>
        </section>

        {/* Shunted与Unshunted结偏置电流比较 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. Shunted与Unshunted结偏置电流比较</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              由于 <MathRenderer formula="R_{eff} < R_J" />，所以 <MathRenderer formula="\alpha_{sh} > \alpha" />，因此：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="i_{bias,c,sh} > i_{bias,c,un}" block />
            </div>
            <p className="mb-4">
              这意味着<strong>shunted JTL需要更高的偏置电流才能维持脉冲传播</strong>，或者说<strong>unshunted JTL所需的最小偏置电流更低</strong>。
            </p>
            <p className="mb-4">
              我们可以通过一个具体例子来说明这一点。假设一个典型的约瑟夫森结参数：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>结电阻 <MathRenderer formula="R_J = 100\Omega" /></li>
              <li>Shunt电阻 <MathRenderer formula="R_{sh} = 20\Omega" /></li>
            </ul>
            <p className="mb-4">
              则等效电阻为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="R_{eff} = \frac{R_J R_{sh}}{R_J + R_{sh}} = \frac{100 \times 20}{100 + 20} = \frac{2000}{120} \approx 16.7\Omega" block />
            </div>
            <p className="mb-4">
              阻尼参数比值：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="\frac{\alpha_{sh}}{\alpha} = \frac{R_J}{R_{eff}} = \frac{100}{16.7} \approx 6" block />
            </div>
            <p className="mb-4">
              这意味着shunted JTL的临界偏置电流约为unshunted JTL的6倍！
            </p>
            <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
              <p className="font-semibold text-yellow-800">关键结论</p>
              <p className="text-yellow-800">
                unshunted结组成的约瑟夫森传输线的偏置电流要比shunted结组成的约瑟夫森传输线偏置电流低，这是由于shunt电阻引入的额外阻尼效应导致的。
              </p>
            </div>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default BiasCurrentPage;
