import { motion } from 'framer-motion';
import MathRenderer from '../components/MathRenderer';

const MechanismsPage = () => {
  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 }
  };

  const pageTransition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-800">Shunt电阻的物理影响机制</h1>

        {/* 能量耗散分析 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">1. 能量耗散分析</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              Shunt电阻本质上是一个能量耗散通道。在约瑟夫森结中，当相位差φ随时间变化时，会产生电压V。这个电压会导致电流通过shunt电阻，从而产生焦耳热损耗：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="P_{loss} = \frac{V^2}{R_{sh}} = \frac{1}{R_{sh}}\left(\frac{\Phi_0}{2\pi}\frac{d\phi}{dt}\right)^2" block />
            </div>
            <p className="mb-4">
              这种额外的能量耗散需要由外部偏置电流提供的能量来补偿，才能维持脉冲的稳定传播。
            </p>
            <p className="mb-4">
              从能量平衡的角度看，偏置电流提供的功率为：
            </p>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <MathRenderer formula="P_{bias} = I_{bias}V_{avg} = I_{bias}\frac{\Phi_0}{2\pi}\left\langle\frac{d\phi}{dt}\right\rangle" block />
            </div>
            <p className="mb-4">
              在稳态传播中，偏置电流提供的能量必须等于系统损耗的能量，包括结电阻和shunt电阻的损耗。由于shunted结具有额外的能量耗散通道，因此需要更高的偏置电流来提供足够的能量。
            </p>
          </div>
        </section>

        {/* 阻尼效应分析 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">2. 阻尼效应分析</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              从物理图像来看，约瑟夫森结的动力学可以通过"摆动模型"来理解：
            </p>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li>约瑟夫森结的动力学方程类似于阻尼摆的运动方程</li>
              <li>相位差φ相当于摆的角度</li>
              <li>阻尼参数α相当于摆的阻尼系数</li>
              <li>偏置电流i相当于施加在摆上的外力</li>
            </ol>
            <p className="mb-4">
              在这个模型中：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Unshunted结相当于低阻尼摆，一旦开始摆动，需要较小的外力维持运动</li>
              <li>Shunted结相当于高阻尼摆，需要较大的外力才能维持相同的运动状态</li>
            </ul>
            <p className="mb-4">
              Shunt电阻的阻尼效应对脉冲高度的影响可以从以下几个方面理解：
            </p>
            <ol className="list-decimal pl-6 mb-4 space-y-2">
              <li><strong>能量重分配</strong>：在shunted结中，部分能量通过shunt电阻以热能形式耗散，减少了可用于脉冲传播的能量</li>
              <li><strong>相位动力学阻尼</strong>：shunt电阻增加了相位动力学的阻尼，限制了相位变化的速率（<MathRenderer formula="\frac{d\phi}{dt}" />），而电压正比于这个变化率</li>
              <li><strong>速度限制效应</strong>：更高的阻尼限制了脉冲的最大传播速度，根据前面的公式，这直接导致脉冲高度的降低</li>
            </ol>
          </div>
        </section>

        {/* 微观物理机制 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">3. 微观物理机制</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              从微观物理角度，shunt电阻对约瑟夫森结性能的影响可以通过以下机制理解：
            </p>
            <h3 className="text-xl font-semibold mb-4 text-blue-700">3.1 准粒子隧穿与Cooper对隧穿的竞争</h3>
            <p className="mb-4">
              在约瑟夫森结中，存在两种电流成分：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>超导电流：由Cooper对隧穿产生，遵循约瑟夫森关系<MathRenderer formula="I_s = I_c\sin(\phi)" /></li>
              <li>准粒子电流：由单电子隧穿产生，表现为欧姆电阻<MathRenderer formula="R_J" /></li>
            </ul>
            <p className="mb-4">
              Shunt电阻的引入增强了准粒子通道的作用，改变了Cooper对隧穿与准粒子隧穿之间的平衡。
            </p>
            <h3 className="text-xl font-semibold mb-4 text-blue-700">3.2 量子相位相干性</h3>
            <p className="mb-4">
              Shunt电阻增加了环境对量子相位的退相干作用，使相位动力学更接近经典行为。这种退相干效应可以通过Caldeira-Leggett模型理解，其中环境（包括shunt电阻）被模拟为谐振子浴，与量子系统（约瑟夫森结）耦合，导致量子相干性的损失。
            </p>
          </div>
        </section>

        {/* Shunt电阻的双重作用 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-blue-800 border-b-2 border-blue-200 pb-2">4. Shunt电阻的双重作用</h2>
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <p className="mb-4">
              Shunt电阻在约瑟夫森结中具有双重作用，这种双重性导致了性能上的权衡：
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
                <h3 className="text-lg font-semibold mb-2 text-green-800">有利作用</h3>
                <ul className="list-disc pl-6 space-y-2 text-green-800">
                  <li><strong>消除迟滞现象</strong>：shunt电阻降低了Stewart-McCumber参数<MathRenderer formula="\beta_c" />，使结从欠阻尼状态转变为过阻尼状态，消除了I-V特性中的迟滞现象</li>
                  <li><strong>提高稳定性</strong>：增加的阻尼使系统对外部扰动的敏感性降低，提高了工作稳定性</li>
                  <li><strong>加快恢复时间</strong>：高阻尼使结在脉冲通过后能更快地恢复到初始状态，提高了最大工作频率</li>
                </ul>
              </div>
              <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
                <h3 className="text-lg font-semibold mb-2 text-red-800">不利作用</h3>
                <ul className="list-disc pl-6 space-y-2 text-red-800">
                  <li><strong>增加偏置电流需求</strong>：如前所述，shunted JTL需要更高的偏置电流才能维持脉冲传播</li>
                  <li><strong>降低脉冲高度</strong>：shunted JTL产生的脉冲高度低于unshunted JTL</li>
                  <li><strong>增加功耗</strong>：更高的偏置电流和额外的shunt电阻导致系统总功耗增加</li>
                </ul>
              </div>
            </div>
            <p className="mb-4">
              在实际应用中，需要根据具体需求在这些因素之间进行权衡：
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>当需要高稳定性和高工作频率时，选择shunted JTL</li>
              <li>当需要低偏置电流和高脉冲高度时，选择unshunted JTL</li>
            </ul>
          </div>
        </section>
      </div>
    </motion.div>
  );
};

export default MechanismsPage;
