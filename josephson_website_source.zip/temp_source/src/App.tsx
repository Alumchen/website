import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ModelsPage from './pages/ModelsPage';
import TransmissionLinePage from './pages/TransmissionLinePage';
import BiasCurrentPage from './pages/BiasCurrentPage';
import PulseHeightPage from './pages/PulseHeightPage';
import MechanismsPage from './pages/MechanismsPage';
import ConclusionsPage from './pages/ConclusionsPage';
import ReferencesPage from './pages/ReferencesPage';
import './App.css';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/models" element={<ModelsPage />} />
            <Route path="/transmission-line" element={<TransmissionLinePage />} />
            <Route path="/bias-current" element={<BiasCurrentPage />} />
            <Route path="/pulse-height" element={<PulseHeightPage />} />
            <Route path="/mechanisms" element={<MechanismsPage />} />
            <Route path="/conclusions" element={<ConclusionsPage />} />
            <Route path="/references" element={<ReferencesPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
